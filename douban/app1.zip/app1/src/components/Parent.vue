<template>
	<div>
		<h2>wwwwwwww</h2>
		<Child></Child>
	</div>
</template>
<script>
	import Child from './Child'
	export default{
		components:{
			Child
		}
	}
</script>