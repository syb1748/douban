<template>
	<div>
		<h2>影院热映</h2><span class="geng">更多</span>
		<img src="../assets/images/images/m1_03.jpg" class="j1">
		<span class="sgen">神奇女侠</span>
		<img src="../assets/images/images/m1_03.jpg" class="j2">
		<img src="../assets/images/images/m1_03.jpg" class="j3">
		<img src="../assets/images/banner/01.jpg" class="j4">
		<span class="xiju">戏剧大师列夫朵金的艺术人生</span>
	</div>
</template>
<style type="text/css">
	.j1{ width: 25%; height: 200px; }
	.j2{ width: 25%; height: 200px; margin-left: 20px;  }
	.j3{ width: 25%; height: 200px; margin-left: 20px;  }
	.j4{ width: 100%; position: absolute; left: 0; top: 350px; }
	.geng{ position: absolute; left: 230px ;top: 41px; color: lightgreen; }
	.sgen{ position: absolute; left: 0; top: 320px;  }
	.xiju{ position: absolute; left: 0; top: 480px; }
</style>