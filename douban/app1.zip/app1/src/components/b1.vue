<template>
	<div>
		<img src="../assets/images/116_02.jpg" class="pic1">
		<img src="../assets/images/ic_rec_group_banner_6.png" class="pic2">
		<span class="tuijian">精选推荐</span>
		<div class="mid1">
			<div class="list1">
				<span class="yi1">影  视</span>
				<div class="box3">
					<img src="../assets/images/images/11111_03.jpg" class="riju">
					<h5>日剧fans</h5>
					<span class="huati1">请自由讨论你热爱日剧的相关话题</span>
					<img src="../assets/images/images/22222_06.jpg" class="renshu">
				</div>
				<div class="box3">
					<img src="../assets/images/images/11111_03.jpg" class="riju">
					<h5 class="h4">日剧fans</h5>
					<span class="huati1">请自由讨论你热爱日剧的相关话题</span>
					<img src="../assets/images/images/22222_06.jpg" class="renshu1">
				</div>
			</div>
		</div>
	</div>
</template>
<style type="text/css">
	.pic1{ width: 100%; position: absolute; left: 0; top: 48px;  }
	.pic2{ width: 90%; position: absolute; left: 5%; top: 228px;}
	.tuijian{ color: #fff; position: absolute; left: 40px; top: 266px; }
	.mid1{ width: 90%; border-top: 1px solid #eee; height: 500px;margin-left: 5%; position: absolute; left: 0; top: 320px;}
	.yi1{ position: absolute; left: 150px; top: -10px; }
	.box3{ width: 80%; height: 60px; padding-top: 10px;}
	.riju{ width: 60px;}
	h5{position: absolute; left: 70px; top: 20px;}
	.huati1{ color: #eee; font-size: 12px; }
	.renshu{ position: absolute; left: 260px; top: 28px; width: 100px;}
	.h4{position: absolute; left: 70px; top: 100px;}
	.renshu1{ position: absolute; left: 260px; top: 100px; width: 100px;}
</style>