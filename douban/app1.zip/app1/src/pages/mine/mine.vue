<template>
	<div>
		<MyHeader>
			<span class='title'>我的</span>
			<img src="../../assets/images/ic_settings.png" class="chat1" slot='right3'>
		</MyHeader>
		<m1>
			<img src="../../assets/images/images/images/m_102_02.jpg" slot='tupian5' class="tu6">	
		</m1>
	</div>
</template>
<script>
	import MyHeader from '../../components/header'
	import M1 from '../../components/m1'
	export default{
		components:{
			MyHeader,
			M1
		}
	}
</script>