<template>
	<div>
		<MyHeader>
			<span class='title'>广播</span>
			<img src="../../assets/images/ic_group_search.png" class="search1" slot='left2'>
			<img src="../../assets/images/ic_create_group_chat_blue.png" class="chat1" slot='right4'>
		</MyHeader>
		<B1>
			
		</B1>
	</div>
</template>
<script>
	import MyHeader from '../../components/header'
	import B1 from '../../components/b1'
	export default{
		components:{
			MyHeader,   
			B1
		}
	}
</script>